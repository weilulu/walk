$(function(){
	alert('hi')
});